package edu.ldj.planner.test;

import edu.ldj.planner.task.*;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.*;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class EasyDateTest{
	private int day;
	private int month;
	private int year;
	
	public EasyDateTest(int ano, int mes, int dia) {
		this.day = dia;
		this.month = mes;
		this.year = ano;
	}
	
	/* DIA:
	 * 	DIA < 1: Inválido
	 * 	DIA >= 1 && DIA <= 31: Válido
	 * 	DIA > 31: Inválido
	 * 
	 * 	EXCEÇÕES:
	 * 		1) Abril, Junho, Setembro e Novembro: DIA >= 1 && DIA <= 30
	 *  	2) Fevereiro, não bissexto: DIA >= 1 && DIA <= 28
	 *  	3) Fevereiro, bissexto: DIA >= 1 && DIA <= 29
	 *  
	 * MÊS
	 * 	MÊS < 1: Inválido
	 *  MÊS >= 1 && MÊS <= 12: Válido
	 *  MÊS > 12: Inválido
	 * 
	 * ANO: Não possui restrições*/
	@Parameters
	public static Object[][] data(){
		return new Object[][] {
			{2022, 3, 0},
			{2022, 7, 20},
			{2022, 1, 32},
			{2022, 4, 31},
			{2021, 2, 29},
			{2020, 2, 29},
			{2022, 0, 13},
			{2022, 5, 19},
			{2022, 13, 17},
			{0, 5, 11}
		};
	}
	
	@Test
	public void testEasyDate() {
		EasyDate data = new EasyDate(year, month, day);
	}
}