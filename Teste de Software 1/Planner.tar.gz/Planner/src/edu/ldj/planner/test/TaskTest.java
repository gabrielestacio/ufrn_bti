package edu.ldj.planner.test;

import edu.ldj.planner.task.*;
import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.runner.*;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class TaskTest{
	private int priority;
	private EasyDate dueDate;
	private double timeEstimate; 
	private String taskName;
	private String taskDetails;
	private String taskClass;
	
	public TaskTest(int prioridade, EasyDate prazo, double tempo, String nome, String detalhes, String classe) {
		this.priority = prioridade;
		this.dueDate = prazo;
		this.timeEstimate = tempo;
		this.taskName = nome;
		this.taskDetails = detalhes;
		this.taskClass = classe;
	}
	
	/* TAMANHO DO NOME:
	 * 	TAM > 12: VÁLIDO
	 * 	TAM <= 12: INVÁLIDO
	 * 
	 * TAMANHO DOS DETALHES:
	 * 	TAM > 30: VÁLIDO
	 * 	TAM <= 30: INVÁLIDO
	 * 
	 * TAMANHO DA CLASSE:
	 * 	TAM > 12: VÁLIDO
	 *  TAM <= 12: INVÁLIDO
	 * 
	 * TAMANHO DO TEMPO ESTIMADO:
	 * 	TAM > 5: VÁLIDO
	 *  TAM <= 5: INVÁLIDO
	 */
}