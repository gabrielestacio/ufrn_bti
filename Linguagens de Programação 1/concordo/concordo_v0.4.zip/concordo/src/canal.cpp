#include <string>
#include <vector>
#include "mensagem.hpp"
#include "canal.hpp"

using namespace std;

//construtor da classe base
Canal::Canal(){
}

//---------------------------------------------------------------------

//retorna o nome do canal
string Canal::getNome(){
	return nome;
}

//função virtual que retorna as mensagens enviadas no canal
vector<Mensagem> Canal::getMensagens(){
	vector<Mensagem> m;
	m.clear();

	return m;
}

//função virtual que retorna o tipo do canal
int Canal::getType(){
	return 0;
}

//---------------------------------------------------------------------

//atribui um nome pro canal
void Canal::setNome(string &name){
	nome = name;
}

//reserva a quantidade de mensagens do canal
void Canal::setMessagesSize(int &tam){
}

//adiciona uma nova mensagem ao canal
void Canal::setMessage(Mensagem &m){
}

//---------------------------------------------------------------------

//função virtual que atribui uma nova mensagem ao canal
void Canal::newMessage(string &mensagem, int autor){
}

//função virtual que cria um novo canal
void Canal::newChannel(vector<string> &stream){
}

//---------------------------------------------------------------------

//função virtual que verifica se um canal já foi cadastrado
bool Canal::searchCanalBool(vector<Canal *> &canais){
	for(long unsigned int i = 0; i < canais.size(); i++){
		if(canais.at(i)->getNome() == nome){
			return true;
		}
	}
	return false;
}

//---------------------------------------------------------------------

//função virtual que anula os valores do canal
void Canal::null(){
}

//---------------------------------------------------------------------

//destrutor da classe base
Canal::~Canal(){
}

//---------------------------------------------------------------------
//---------------------------------------------------------------------

//construtor da classe derivada
CanalTexto::CanalTexto(){
}

//---------------------------------------------------------------------

//função virtual que retorna as mensagens do canal
vector<Mensagem> CanalTexto::getMensagens(){
	return mensagens;
}

//função virtual que retorna o tipo do canal
int CanalTexto::getType(){
	return 1;
}

//---------------------------------------------------------------------
									
//insere a quantidade de mensagens do canal
void CanalTexto::setMessagesSize(int &tam){
	mensagens.reserve(tam);
}

//insere uma mensagem passada no canal
void CanalTexto::setMessage(Mensagem &m){
	mensagens.push_back(m);
}

//---------------------------------------------------------------------

//função virtual que atribui uma nova mensagem ao canal
void CanalTexto::newMessage(string &mensagem, int autor){
	Mensagem m;

	m.newMessage(mensagem, autor);
	mensagens.push_back(m);
}

//função virtual que cria um novo canal
void CanalTexto::newChannel(vector<string> &stream){
	setNome(stream[1]);
	mensagens.clear();
}

//---------------------------------------------------------------------

//função virtual que verifica se um canal já foi cadastrado
bool CanalTexto::searchCanalBool(vector<Canal *> &canais){
	for(long unsigned int i = 0; i < canais.size(); i++){
		if(canais.at(i)->getNome() == getNome()){
			if(canais.at(i)->getType() == 1){
				return true;
			}
		}
	}
	return false;
}

//---------------------------------------------------------------------

//função virtual que anula os valores do canal
void CanalTexto::null(){
	string vazio = "\0";
	setNome(vazio);
	mensagens.clear();
}

//---------------------------------------------------------------------

//destrutor da classe derivada
CanalTexto::~CanalTexto(){
}

//---------------------------------------------------------------------
//---------------------------------------------------------------------

//construtor da classe derivada
CanalVoz::CanalVoz(){
}

//---------------------------------------------------------------------

//função virtual que retorna as mensagens enviadas no canal
vector<Mensagem> CanalVoz::getMensagens(){
	ultima.clear();
	ultima.push_back(ultimaMensagem);
	return ultima;
}

//função virtual que retorna o tipo do canal
int CanalVoz::getType(){
	return 2;
}

//---------------------------------------------------------------------
									
//insere a quantidade de mensagens do canal
void CanalVoz::setMessagesSize(int &tam){
	return;
}

//insere uma mensagem passada no canal
void CanalVoz::setMessage(Mensagem &m){
	ultimaMensagem = m;
}

//---------------------------------------------------------------------

//função virtual que atribui uma nova mensagem ao canal
void CanalVoz::newMessage(string &mensagem, int autor){
	Mensagem m;
	
	m.newMessage(mensagem, autor);
	ultimaMensagem = m;
}

//função virtual que cria um novo canal
void CanalVoz::newChannel(vector<string> &stream){
	setNome(stream[1]);
	ultimaMensagem.null();
}

//---------------------------------------------------------------------

//função virtual que verifica se um canal já foi cadastrado
bool CanalVoz::searchCanalBool(vector<Canal *> &canais){
	for(long unsigned int i = 0; i < canais.size(); i++){
		if(canais.at(i)->getNome() == getNome()){
			if(canais.at(i)->getType() == 2){
				return true;
			}
		}
	}
	return false;
}

//---------------------------------------------------------------------

//função virtual que anula os valores do canal
void CanalVoz::null(){
	string vazio = "\0";
	setNome(vazio);
	ultimaMensagem.null();
}

//---------------------------------------------------------------------

//destrutor da classe derivada
CanalVoz::~CanalVoz(){
}