				switch(cntrl){
					case 0:
						id = stoi(line, nullptr);
						s->setDonoId(id);
						cntrl++;
						break;
					case 1:
						s->setNome(line);
						cntrl++;
						break;
					case 2:
						s->setDescricao(line);
						cntrl++;
						break;
					case 3:
						s->setCodigo(line);
						cntrl++;
						break;
					case 4:
						tam_u = stoi(line, nullptr);
						s->setParticipantesSize(tam_u);
						cntrl++;
						break;
					case 5:
						tam_u--;
						id = stoi(line, nullptr);
						s->setParticipantes(id);
						if(tam_u == 0){
							cntrl++;
						}
						break;
					case 6:
						tam_c = stoi(line, nullptr);
						s->setCanaisSize(tam_c);
						cntrl++;
						break;
					case 7:
						tam_c--;
						nome = line;
						cntrl++;
						break;
					case 8:
						if(line == "TEXTO"){
							c = new CanalTexto;
						}
						else{
							c = new CanalVoz;
						}
						c->setNome(nome);
						cntrl++;
						break;
					case 9:
						tam_m = stoi(line, nullptr);
						c->setMessagesSize(tam_m);
						cntrl++;
						break;
					case 10:
						tam_m--;
						id = stoi(line, nullptr);
						m->setAutor(id);
						cntrl++;
						break;
					case 11:
						m->setData(line);
						cntrl++;
						break;
					case 12:
						m->setConteudo(line);
						c->setMessage(*m);
						m->null();
						
						if(tam_m != 0){
							cntrl = 10;
							break;
						}
				
						s->setCanal(c);
						c->null();
				
						if(tam_c != 0){
							cntrl = 7;
							break;
						}
				
						servidores.push_back(*s);
						salvaCanais();
						s->null();
						for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
							carregaCanais(*it);
						}
				
						cntrl = 0;
						break;
					default:
						break;
				}