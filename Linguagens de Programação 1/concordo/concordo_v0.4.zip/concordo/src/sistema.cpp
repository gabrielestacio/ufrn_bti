#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "canal.hpp"
#include "mensagem.hpp"
#include "usuario.hpp"
#include "servidor.hpp"
#include "sistema.hpp"

using namespace std;

void Sistema::salvarUsuarios(){
	ofstream users;

	if(usuarios.empty()){
		return;
	}
	else{
		users.open("usuarios.txt");
		users << usuarios.size() << endl;
		for(vector<Usuario>::iterator it = usuarios.begin(); it != usuarios.end(); it++){
			users << it->getId() << endl;
			users << it->getNome() << endl;
			users << it->getEmail() << endl;
			//Só pra não ficar com a última linha do arquivo como uma linha vazia
			if((it+1) == usuarios.end()){
				users << it->getSenha();
			}
			else{
				users << it->getSenha() << endl;
			}
		}
		users.close();
	}
}

void Sistema::salvarServidores(){
	ofstream servers;

	if(servidores.empty()){
		return;
	}
	else{
		servers.open("servidores.txt");
		servers << servidores.size() << endl;
		for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
			servers << it->getDonoId() << endl;
			servers << it->getNome() << endl;
			servers << it->getDescricao() << endl;
			servers << it->getCodigo() << endl;
			servers << it->getParticipantes().size() << endl;
			if(it->getParticipantes().empty() != true){
				for(long unsigned int i = 0; i < it->getParticipantes().size(); i++){
					servers << it->getParticipantes().at(i) << endl;
				}
			}
			else{
				servers << endl;
			}
			servers << it->getCanais().size() << endl;
			if(it->getCanais().empty() == false){
				for(long unsigned int i = 0; i < it->getCanais().size(); i++){
					servers << it->getCanais().at(i)->getNome() << endl;	
					if(it->getCanais().at(i)->getType() == 1){
						servers << "TEXTO" << endl;
					}
					else{
						servers << "VOZ" << endl;
					}			
					servers << it->getCanais().at(i)->getMensagens().size() << endl;
					for(long unsigned int j = 0; j < it->getCanais().at(i)->getMensagens().size(); j++){
						servers << it->getCanais().at(i)->getMensagens().at(j).getAutor() << endl;
						servers << it->getCanais().at(i)->getMensagens().at(j).getData() << endl;
						//Só pra não ficar com a última linha do arquivo como uma linha vazia
						if(((it+1) == servidores.end()) && ((i+1) == it->getCanais().size()) && ((j+1) == it->getCanais().at(i)->getMensagens().size())){
							servers << it->getCanais().at(i)->getMensagens().at(j).getConteudo();
						}
						else{
							servers << it->getCanais().at(i)->getMensagens().at(j).getConteudo() << endl;
						}
					}
				}
			}
		}
		servers.close();
	}
}

void Sistema::carregarUsuarios(){
	ifstream users;
	string line; //Armazena a linha do arquivo
	int tamanho = 0, id = 0, cntrl = 0; //Quantos usuários serão cadastrados, ID do usuário, Status do usuário a ser cadastrado
	Usuario *u = new Usuario; //Usuario que será cadastrado

	usuarios.clear();

	//Inicializando o usuário
	u->null();

	users.open("usuarios.txt");
	if(users.is_open()){
		while(getline(users, line)){
			//Pegando o tamanho do vetor de usuários
			if(tamanho == 0){
				tamanho = stoi(line, nullptr);
				usuarios.reserve(tamanho);
			}
			else{
				//Pegando as informações do usuário
				switch(cntrl){
					case 0: //Insere ID
						id = stoi(line, nullptr);
						u->setId(id);
						cntrl++;
						break;
					case 1: //Insere Nome
						u->setNome(line);
						cntrl++;
						break;
					case 2: //Insere Email
						u->setEmail(line);
						cntrl++;
						break;
					case 3: //Insere Senha
						u->setSenha(line);
						cntrl++;

						//Usuário pronto pra ser adicionado. Verificando se tem informações faltantes.
						if((u->getId() == 0) || (u->getNome() == "\0") || (u->getEmail() == "\0") || (u->getSenha() == "\0")){
							cout << "ERRO: Arquivo corrompido. Foram detectadas informações faltantes." << endl;
							return;
						}
						else{
							usuarios.push_back(*u);
							u->null();
						}
						cntrl = 0;

						break;
					default:
						break;
				}
			}
		}
	}
	users.close();
	delete u;
}

void Sistema::carregarServidores(){
	ifstream servers;
	string line, nome; //Armazena a linha do arquivo, Armazena o nome do canal até saber o tipo
	int tamanho = 0, tam_u = 0, tam_c = 0, tam_m = 0, id = 0, cntrl = 0;
	Servidor *s = new Servidor; //Servidor que será cadastrado
	Canal *c;
	Mensagem *m = new Mensagem;

	servidores.clear();

	/*salvaCanais();
	s->null();
	for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
		carregaCanais(*it);
	}*/
	m->null();

	servers.open("servidores.txt");
	if(servers.is_open()){
		while(getline(servers, line)){
			//Pegando o tamanho do vetor de servidores
			if(tamanho == 0){
				tamanho = stoi(line, nullptr);
				servidores.reserve(tamanho);
			}
			else{
				switch(cntrl){
					case 0:
						if(line != "\0"){
							id = stoi(line, nullptr);
							s->setDonoId(id);
						}
						cntrl++;
						break;
					case 1:
						s->setNome(line);
						cntrl++;
						break;
					case 2:
						s->setDescricao(line);
						cntrl++;
						break;
					case 3:
						s->setCodigo(line);
						cntrl++;
						break;
					case 4:
						tam_u = stoi(line, nullptr);
						s->setParticipantesSize(tam_u);
						cntrl++;
						break;
					case 5:
						if(tam_u > 0){
							if(tam_u == 1){
								cntrl++;
							}
							tam_u--;
							id = stoi(line, nullptr);
							s->setParticipantes(id);
						}
						else{
							cntrl++;
						}
						break;
					case 6:
						tam_c = stoi(line, nullptr);
						s->setCanaisSize(tam_c);
						if(tam_c == 0){
							servidores.push_back(*s);
							salvaCanais();
							s->null();
							for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
								carregaCanais(*it);
							}
							cntrl = 0;
							break;
						}
						cntrl++;
						break;
					case 7:
						if(tam_c == 0){
							servidores.push_back(*s);
							salvaCanais();
							s->null();
							for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
								carregaCanais(*it);
							}
							cntrl = 0;
							break;
						}
						tam_c--;
						nome = line;
						cntrl++;
						break;
					case 8:
						if(line == "TEXTO"){
							c = new CanalTexto;
						}
						else{
							c = new CanalVoz;
						}
						c->setNome(nome);
						cntrl++;
						break;
					case 9:
						tam_m = stoi(line, nullptr);
						c->setMessagesSize(tam_m);
						if(tam_m == 0){
							s->setCanal(c);
							if(tam_c == 0){
								servidores.push_back(*s);
								salvaCanais();
								s->null();
								for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
									carregaCanais(*it);
								}
								cntrl = 0;
							}
							else{
								cntrl = 7;
							}
							break;
						}
						cntrl++;
						break;
					case 10:
						if(tam_m == 0){
							s->setCanal(c);
							if(tam_c == 0){
								servidores.push_back(*s);
								salvaCanais();
								s->null();
								for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
									carregaCanais(*it);
								}
								cntrl = 0;
							}
							else{
								cntrl = 7;
							}
							break;
						}
						tam_m--;
						id = stoi(line, nullptr);
						m->setAutor(id);
						cntrl++;
						break;
					case 11:
						m->setData(line);
						cntrl++;
						break;
					case 12:
						m->setConteudo(line);
						c->setMessage(*m);
						m->null();
						
						if(tam_m != 0){
							cntrl = 10;
							break;
						}
				
						s->setCanal(c);
				
						if(tam_c != 0){
							cntrl = 7;
							break;
						}

						if((s->getNome() == "\0") || (s->getDonoId() == 0)){
							cout << "ERRO: Arquivo corrompido. Foram detectadas informações faltantes." << endl;
							return;
						}
				
						servidores.push_back(*s);
						salvaCanais();
						s->null();
						for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
							carregaCanais(*it);
						}
				
						cntrl = 0;
						break;
					default:
						break;
				}	
			}
		}
	}
	servers.close();
	delete s;
	delete m;
}

//---------------------------------------------------------------------

//construtor
Sistema::Sistema(){
	canalAtivo = new Canal;
	null = new Canal;
}

//---------------------------------------------------------------------

void Sistema::salvar(){
	salvarUsuarios();
	salvarServidores();
}

void Sistema::carregar(){
	carregarUsuarios();
	carregarServidores();
}

//---------------------------------------------------------------------

//retorna os usuários cadastrados
vector<Usuario> Sistema::getUsuarios(){
	return usuarios;
}

//retorna os servidores cadastrados
vector<Servidor> Sistema::getServidores(){
	return servidores;
}

//retorna o usuário ativo
Usuario Sistema::getUsuarioAtivo(){
	return usuarioAtivo;
}

//retorna o servidor ativo
Servidor Sistema::getServidorAtivo(){
	return servidorAtivo;
}

//retorna o canal ativo
Canal Sistema::getCanalAtivo(){
	return *canalAtivo;
}

//---------------------------------------------------------------------

//busca um usuário pelo ID
Usuario Sistema::searchById(int id){
	Usuario user;

	for (long unsigned int i = 0; i < usuarios.size(); i++){
		user = usuarios[i];
		if(user.getId() == id){
			return user;
		}
	}
	return user.null();
}

//verifica se o email de um usuário já foi cadastrado
bool Sistema::searchUser(Usuario user){
	vector<Usuario>::iterator it;

	for(it = usuarios.begin(); it != usuarios.end(); it++){
		if(it->getEmail() == user.getEmail()){
			return true;
		}
	}
	return false;
}

//verifica se já existe um servidor com aquele nome
bool Sistema::searchServer(Servidor server){
	vector<Servidor>::iterator it;

	for(it = servidores.begin(); it != servidores.end(); it++){
		if((it->getNome() == server.getNome()) && (it->getDonoId() == server.getDonoId())){
			return true;
		}
	}
	return false;
}

//---------------------------------------------------------------------

//adiciona um usuário 
void Sistema::createUser(vector<string> &stream, int &id){
	Usuario user;

	user.newUser(stream, id);

	if(usuarios.empty() == true){
		usuarios.push_back(user);
		cout << "Usuário criado com sucesso." << endl;
	}
	else{
		if(searchUser(user) == false){
			usuarios.push_back(user);
			cout << "Usuário criado com sucesso." << endl;
		}
		else{
			cout << "ERRO: Esse email já foi vinculado a outro usuário." << endl;
		}
	}
}

//adiciona um servidor
void Sistema::createServer(vector<string> &stream, int &id){
	Servidor server;

	server.newServer(stream, id);

	if(servidorAtivo.getNome() == "\0"){
		if(servidores.empty() == true){
			servidores.push_back(server);
			cout << "Servidor criado com sucesso." << endl;
		}
		else{
			if(searchServer(server) == false){
				servidores.push_back(server);
				cout << "Servidor criado com sucesso." << endl;
			}
			else{
				cout << "ERRO: Esse servidor já foi cadastrado." << endl;
			}
		}
	}
	else{
		cout << "ERRO: Você precisa sair do servidor ativo para criar um novo." << endl;
	}
}

//criando um canal no servidor
void Sistema::createChannel(vector<string> &stream){
	if(canalAtivo->getNome() != "\0"){
		cout << "ERRO: Você precisa sair do canal ativo para criar outro." << endl;
		return;
	}

	if(servidorAtivo.getDonoId() == usuarioAtivo.getId()){
		servidorAtivo.newChannel(stream);	
	}
	else{
		cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl;
	}
}

//---------------------------------------------------------------------

//efetua login
void Sistema::login(vector<string> stream){
	vector<Usuario>::iterator it;

	for(it = usuarios.begin(); it != usuarios.end(); it++){
		if((it->getEmail() == stream[1]) && (it->getSenha() == stream[2])){
			usuarioAtivo = *it;
			cout << "Logado como " << usuarioAtivo.getEmail() << endl;
			return;
		}
	}
	cout << "ERRO: Email ou senha incorretos." << endl;
}

//desconecta o usuário
void Sistema::disconnect(){
	cout << "Desconectando usuário " << usuarioAtivo.getEmail() << endl;
	usuarioAtivo.null();
	/*canalAtivo->null();
	salvaCanais();
	servidorAtivo.null();*/
}

//---------------------------------------------------------------------

//insere uma descrição para o servidor
void Sistema::setDesc(vector<string> &stream){
	Servidor server;
	string desc = "\0";
	vector<string>::iterator it_st;
	vector<Servidor>::iterator it_se;

	for(it_st = stream.begin()+2; it_st != stream.end(); it_st++){
		if(it_st == stream.begin()+2){
			desc = *it_st;
		}
		else{
			desc += " " + *it_st;
		}
	}

	for(it_se = servidores.begin(); it_se != servidores.end(); it_se++){
		if((it_se->getNome() == stream[1]) && (it_se->getDonoId() == usuarioAtivo.getId())){
			it_se->setDescricao(desc);
			cout << "Descrição de " << it_se->getNome() << " alterada com sucesso." << endl;
			return;
		}
		else if((it_se->getNome() == stream[1]) && (it_se->getDonoId() != usuarioAtivo.getId())){
			cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl; 
			return;
		}
	}
	cout << "ERRO: O servidor especificado não existe." << endl;
}

//insere um código de convite para o servidor
void Sistema::setCode(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			if(it->getDonoId() != usuarioAtivo.getId()){
				cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl;
				return;
			}
			else{
				if(stream.size() < 3){
					string temp = "\0";
					it->setCodigo(temp);
				}
				else{
					it->setCodigo(stream[2]);
				}
				cout << "Código de convite do servidor " << it->getNome() << " foi alterado." << endl;
				return;
			}
		}
	}
	cout << "ERRO: O servidor especificado não existe." << endl;
}

//---------------------------------------------------------------------

//lista os servidores cadastrados no sistema
void Sistema::listServers(){
	vector<Servidor>::iterator it;

	if(servidores.empty() == true){
		cout << "ERRO: Nenhum servidor cadastrado." << endl;
		return;
	}

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getDonoId() == usuarioAtivo.getId()){
			cout << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << endl;
		}
		else{
			if(it->getCodigo() == "\0"){
				cout << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << endl;
			}
			for(vector<int>::iterator it_serv = it->getParticipantes().begin(); it_serv != it->getParticipantes().end(); it_serv++){
				if(*it_serv == usuarioAtivo.getId()){
					cout << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << endl;
				}
			}
		}
	}
}

//listando os participantes de um servidor
void Sistema::listParticipants(){	
	Usuario user;
	vector<int> participantes = servidorAtivo.getParticipantes();
	vector<int>::iterator it;

	for(it = participantes.begin(); it != participantes.end(); it++){
		user = searchById(*it);
		cout << user.getNome() << " | " << user.getEmail() << endl;
		/*if(user.getNome() != "\0"){
		}*/
	}
}

//listando os canais do servidor
void Sistema::listChannels(){
	servidorAtivo.listChannels();
}

//listando as mensagens enviadas
void Sistema::listMessages(){
	vector<Mensagem> mensagens = canalAtivo->getMensagens();
	vector<Mensagem>::iterator it;
	Usuario user;

	if(mensagens.empty() == false){
		for(it = mensagens.begin(); it != mensagens.end(); it++){
			user = searchById(it->getAutor());
			cout << user.getNome() << " [" << it->getData() << "]: " << it->getConteudo() << endl;
		}
	}
	else{
		cout << "ERRO: Sem mensagens para exibir." << endl;
	}
}

//---------------------------------------------------------------------

//exclui um servidor do sistema
void Sistema::removeServer(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			if(it->getDonoId() == usuarioAtivo.getId()){
				servidores.erase(it);
				cout << "Servidor " << stream[1] << " removido do sistema." << endl;
				return;
			}
			else{
				cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl;
				return;
			}
		}
	}
	cout << "ERRO: Servidor " << stream[1] << " não foi encontrado." << endl;
}

//---------------------------------------------------------------------

//entra em um servidor
void Sistema::enterServer(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;
	vector<Canal> cpy;
	int i = 0;

	if(servidorAtivo.getNome() != "\0"){
		cout << "ERRO: Você já está conectado em outro servidor." << endl;
		return;
	}

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			//verifica se o usuário é dono do servidor
			if(it->getDonoId() == usuarioAtivo.getId()){
				cout << usuarioAtivo.getNome() << " entrou no servidor com sucesso." << endl;
				it->novoParticipante(usuarioAtivo);
				servidorAtivo = *it;
				carregaCanais(servidorAtivo);
				salvar();
			}
			else{
				//verifica se o canal tem código de convite
				if(it->getCodigo() == "\0"){
					cout << usuarioAtivo.getNome() << " entrou no servidor com sucesso." << endl;
					it->novoParticipante(usuarioAtivo);
					servidorAtivo = *it;
					carregaCanais(servidorAtivo);
					salvar();
				}
				else{
					if(stream.size() < 3){
						cout << "ERRO: Servidor requer código de convite." << endl;
					}
					else{
						//verifica se o código passado é correto
						if(stream[2] == it->getCodigo()){
							cout << usuarioAtivo.getNome() << " entrou no servidor com sucesso." << endl;
							it->novoParticipante(usuarioAtivo);
							servidorAtivo = *it;
							carregaCanais(servidorAtivo);
							salvar();		
						}
						else{
							cout << "ERRO: Código de convite incorreto." << endl;
						}
					}
				}
			}
			return;
		}
		i++;
	}
	cout << "ERRO: Servidor não cadastrado." << endl;
}

//entrando num canal
void Sistema::enterChannel(vector<string> &stream){
	int trigger = 0; //vai controlar se um canal já apareceu na busca. Se sim, trigger recebe 1.
	bool repetido = false; //vai controlar se existe mais de um canal com o nome passado
	vector<Canal *> canais = servidorAtivo.getCanais();

	if(servidorAtivo.searchCanal(stream[1])->getNome() != "\0"){
		if(stream.size() < 3){
			for(vector<Canal *>::iterator it = canais.begin(); it != canais.end(); it++){
				//verifica se um nome passado pertence a mais de um canal e faz as devidas operações a partir disso
				if(trigger == 0){
					if((*it)->getNome() == stream[1]){
						trigger = 1;
					}
				}
				else{
					if((*it)->getNome() == stream[1]){
						repetido = true;
					}
				}
			}
			if(repetido == true){
				cout << "ERRO: Existe mais de um canal com este nome. Especifique o tipo do canal que você quer alterar." << endl;
				return;
			}
			canalAtivo = servidorAtivo.searchCanal(stream[1]);
			cout << "Entrando no canal \'" << canalAtivo->getNome() << "\'." << endl;
		}
		else{
			canalAtivo = servidorAtivo.searchCanal(stream[1], stream[2]);
			if(canalAtivo->getNome() != "\0"){ //se o retorno for "tipo inválido", não vai imprimir que está entrando no canal
				cout << "Entrando no canal \'" << canalAtivo->getNome() << "\'." << endl;
			}
		}
	}
	else{
		cout << "ERRO: Canal \'" << stream[1] << "\' não existe." << endl;
	}
}

//---------------------------------------------------------------------

//saindo do servidor
void Sistema::leaveServer(){
	vector<Canal *> c;

	c.push_back(nullptr);

	if(servidorAtivo.getNome() == "\0"){
		cout << "ERRO: Nenhum servidor ativo." << endl;
	}
	else{
		cout << "Saindo do servidor " << servidorAtivo.getNome() << endl;
		salvaCanais();
		servidorAtivo.null();
		for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
			carregaCanais(*it);
		}
	}
}

//saindo de um canal
void Sistema::leaveChannel(){
	if(canalAtivo->getNome() != "\0"){
		cout << "Saindo do canal \'" << canalAtivo->getNome() << "\'." << endl;
		canalAtivo = null;
	}
	else{
		cout << "ERRO: Nenhum canal ativo." << endl;
	}
}

//---------------------------------------------------------------------

//enviando uma mensagem
void Sistema::sendMessage(vector<string> &stream){
	string mensagem = stream[1];

	//juntando  a mensagem
	for(long unsigned int i = 2; i < stream.size(); i++){
		mensagem += " " + stream[i];
	}

	canalAtivo->newMessage(mensagem, usuarioAtivo.getId());
}

//---------------------------------------------------------------------

//salva os canais de um servidor antes de serem anulados no leave-server
void Sistema::salvaCanais(){
	bool ja_tem = false;

	if(servidorAtivo.getCanais().empty() == false){
		for(vector<string>::iterator it = index.begin(); it != index.end(); it++){
			if(*it == servidorAtivo.getNome()){
				ja_tem = true;
				break;
			}
		}
		if(ja_tem == false){
			canais.push_back(servidorAtivo.getCanais());
			index.push_back(servidorAtivo.getNome());
		}
	}
}

//carrega os canais de um servidor ao ser ativado pelo enter-server
void Sistema::carregaCanais(Servidor &serv){
	for(long unsigned int i = 0; i < index.size(); i++){
		if(index.at(i) == serv.getNome()){
			serv.setCanais(canais.at(i));
			return;
		}
	}
}

//---------------------------------------------------------------------

//destrutor
Sistema::~Sistema(){
}