#ifndef _CANAL_HPP_
#define _CANAL_HPP_

#include <string>
#include <vector>
#include "mensagem.hpp"

using namespace std;

class Canal{
		string nome;
	public:
		Canal();
		//---------------------------------------------------------------------
		string getNome();
		virtual vector<Mensagem> getMensagens();
		virtual int getType();
		//---------------------------------------------------------------------
		void setNome(string &name);
		virtual void setMessagesSize(int &tam);
		virtual void setMessage(Mensagem &m);
		//---------------------------------------------------------------------
		virtual void newMessage(string &mensagem, int autor);
		virtual void newChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		virtual bool searchCanalBool(vector<Canal *> &canais);
		//---------------------------------------------------------------------
		virtual void null();
		//---------------------------------------------------------------------
		~Canal();
};

class CanalTexto: public Canal{
		vector<Mensagem> mensagens;
	public:
		CanalTexto();
		//---------------------------------------------------------------------
		virtual vector<Mensagem> getMensagens();
		virtual int getType();
		//---------------------------------------------------------------------
		virtual void setMessagesSize(int &tam);
		virtual void setMessage(Mensagem &m);
		//---------------------------------------------------------------------
		virtual void newMessage(string &mensagem, int autor);
		virtual void newChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		virtual bool searchCanalBool(vector<Canal *> &canais);
		//---------------------------------------------------------------------
		virtual void null();
		//---------------------------------------------------------------------
		~CanalTexto();
};
class CanalVoz: public Canal{
		Mensagem ultimaMensagem;
	public:
		vector<Mensagem> ultima;
		//---------------------------------------------------------------------
		CanalVoz();
		//---------------------------------------------------------------------
		virtual vector<Mensagem> getMensagens();
		virtual int getType();
		//---------------------------------------------------------------------
		virtual void setMessagesSize(int &tam);
		virtual void setMessage(Mensagem &m);
		//---------------------------------------------------------------------
		virtual void newMessage(string &mensagem, int autor);
		virtual void newChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		virtual bool searchCanalBool(vector<Canal *> &canais);
		//---------------------------------------------------------------------
		virtual void null();
		//---------------------------------------------------------------------
		~CanalVoz();
};

#endif