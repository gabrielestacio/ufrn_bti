#ifndef _SISTEMA_HPP_
#define _SISTEMA_HPP_

#include <vector>
#include <string>
#include "usuario.hpp"
#include "servidor.hpp"
#include "mensagem.hpp"
#include "canal.hpp"

using namespace std;

class Sistema{
		vector<Usuario> usuarios;
		vector<Servidor> servidores;
		vector<vector<Canal *>> canais;
		vector<string> index;
		Usuario usuarioAtivo;
		Servidor servidorAtivo;
		Canal *canalAtivo;
		Canal *null;

		void salvarUsuarios();
		void salvarServidores();
		void carregarUsuarios();
		void carregarServidores();
	public:
		Sistema();
		//---------------------------------------------------------------------
		void salvar();
		void carregar();
		//---------------------------------------------------------------------
		vector<Usuario> getUsuarios();
		vector<Servidor> getServidores();
		Usuario getUsuarioAtivo();
		Servidor getServidorAtivo();
		Canal getCanalAtivo();
		//---------------------------------------------------------------------
		Usuario searchById(int id);
		bool searchUser(Usuario user);
		bool searchServer(Servidor server);
		//---------------------------------------------------------------------
		void createUser(vector<string> &stream, int &sid);
		void createServer(vector<string> &stream, int &id);
		void createChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		void login(vector<string> stream);
		void disconnect();
		//---------------------------------------------------------------------
		void setDesc(vector<string> &stream);
		void setCode(vector<string> &stream);
		//---------------------------------------------------------------------
		void listServers();
		void listParticipants();
		void listChannels();
		void listMessages();
		//---------------------------------------------------------------------
		void removeServer(vector<string> &stream);
		//---------------------------------------------------------------------
		void enterServer(vector<string> &stream);
		void enterChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		void leaveServer();
		void leaveChannel();
		//---------------------------------------------------------------------
		void sendMessage(vector<string> &stream);
		//---------------------------------------------------------------------
		void salvaCanais();
		void carregaCanais(Servidor &serv);
		//---------------------------------------------------------------------
		~Sistema();
};

#endif