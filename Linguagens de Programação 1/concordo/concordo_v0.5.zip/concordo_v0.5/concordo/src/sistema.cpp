#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "canal.hpp"
#include "mensagem.hpp"
#include "usuario.hpp"
#include "servidor.hpp"
#include "sistema.hpp"

using namespace std;

void Sistema::salvarUsuarios(){
	ofstream users;

	if(usuarios.empty()){
		return;
	}
	else{
		users.open("usuarios.txt");
		users << usuarios.size() << endl;
		for(vector<Usuario>::iterator it = usuarios.begin(); it != usuarios.end(); it++){
			users << it->getId() << endl;
			users << it->getNome() << endl;
			users << it->getEmail() << endl;
			//Só pra não ficar com a última linha do arquivo como uma linha vazia
			if((it+1) == usuarios.end()){
				users << it->getSenha();
			}
			else{
				users << it->getSenha() << endl;
			}
		}
		users.close();
	}
}

void Sistema::salvarServidores(){
	ofstream servers;

	if(servidores.empty()){
		return;
	}
	else{
		servers.open("servidores.txt");
		servers << servidores.size() << endl;
		for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
			servers << it->getDonoId() << endl;
			servers << it->getNome() << endl;
			servers << it->getDescricao() << endl;
			servers << it->getCodigo() << endl;
			servers << it->getParticipantes().size() << endl;
			if(it->getParticipantes().empty() != true){
				for(long unsigned int i = 0; i < it->getParticipantes().size(); i++){
					servers << it->getParticipantes().at(i) << endl;
				}
			}
			else{
				servers << endl;
			}
			servers << it->getCanais().size() << endl;
			if(it->getCanais().empty() == false){
				for(long unsigned int i = 0; i < it->getCanais().size(); i++){
					servers << it->getCanais().at(i)->getNome() << endl;	
					if(it->getCanais().at(i)->getType() == 1){
						servers << "TEXTO" << endl;
					}
					else{
						servers << "VOZ" << endl;
					}			
					servers << it->getCanais().at(i)->getMensagens().size() << endl;
					for(long unsigned int j = 0; j < it->getCanais().at(i)->getMensagens().size(); j++){
						servers << it->getCanais().at(i)->getMensagens().at(j).getAutor() << endl;
						servers << it->getCanais().at(i)->getMensagens().at(j).getData() << endl;
						//Só pra não ficar com a última linha do arquivo como uma linha vazia
						if(((it+1) == servidores.end()) && ((i+1) == it->getCanais().size()) && ((j+1) == it->getCanais().at(i)->getMensagens().size())){
							servers << it->getCanais().at(i)->getMensagens().at(j).getConteudo();
						}
						else{
							servers << it->getCanais().at(i)->getMensagens().at(j).getConteudo() << endl;
						}
					}
				}
			}
		}
		servers.close();
	}
}

void Sistema::carregarUsuarios(){
	ifstream users;
	string line; //Armazena a linha do arquivo
	int tamanho = 0, id = 0, cntrl = 0; //Quantos usuários serão cadastrados, ID do usuário, Status do usuário a ser cadastrado
	Usuario *u = new Usuario; //Usuario que será cadastrado

	usuarios.clear();

	//Inicializando o usuário
	u->null();

	users.open("usuarios.txt");
	if(users.is_open()){
		while(getline(users, line)){
			//Pegando o tamanho do vetor de usuários
			if(tamanho == 0){
				tamanho = stoi(line, nullptr);
				usuarios.reserve(tamanho);
			}
			else{
				//Pegando as informações do usuário
				switch(cntrl){
					case 0: //Insere ID
						id = stoi(line, nullptr);
						u->setId(id);
						cntrl++;
						break;
					case 1: //Insere Nome
						u->setNome(line);
						cntrl++;
						break;
					case 2: //Insere Email
						u->setEmail(line);
						cntrl++;
						break;
					case 3: //Insere Senha
						u->setSenha(line);
						cntrl++;

						//Usuário pronto pra ser adicionado. Verificando se tem informações faltantes.
						if((u->getId() == 0) || (u->getNome() == "\0") || (u->getEmail() == "\0") || (u->getSenha() == "\0")){
							cout << "ERRO: Arquivo corrompido. Foram detectadas informações faltantes." << endl;
							return;
						}
						else{
							usuarios.push_back(*u);
							u->null();
						}
						cntrl = 0;

						break;
					default:
						break;
				}
			}
		}
	}
	users.close();
	delete u;
}

void Sistema::carregarServidores(){
	ifstream servers;
	string line, nome; //Armazena a linha do arquivo, Armazena o nome do canal até saber o tipo
	int tamanho = 0, tam_u = 0, tam_c = 0, tam_m = 0, id = 0, cntrl = 0;
	Servidor *s = new Servidor; //Servidor que será cadastrado
	Canal *c;
	Mensagem *m = new Mensagem;

	servidores.clear();

	/*salvaCanais();
	s->null();
	for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
		carregaCanais(*it);
	}*/
	m->null();

	servers.open("servidores.txt");
	if(servers.is_open()){
		while(getline(servers, line)){
			//Pegando o tamanho do vetor de servidores
			if(tamanho == 0){
				tamanho = stoi(line, nullptr);
				servidores.reserve(tamanho);
			}
			else{
				switch(cntrl){
					case 0:
						if(line != "\0"){
							id = stoi(line, nullptr);
							s->setDonoId(id);
						}
						cntrl++;
						break;
					case 1:
						s->setNome(line);
						cntrl++;
						break;
					case 2:
						s->setDescricao(line);
						cntrl++;
						break;
					case 3:
						s->setCodigo(line);
						cntrl++;
						break;
					case 4:
						tam_u = stoi(line, nullptr);
						s->setParticipantesSize(tam_u);
						cntrl++;
						break;
					case 5:
						if(tam_u > 0){
							if(tam_u == 1){
								cntrl++;
							}
							tam_u--;
							id = stoi(line, nullptr);
							s->setParticipantes(id);
						}
						else{
							cntrl++;
						}
						break;
					case 6:
						tam_c = stoi(line, nullptr);
						s->setCanaisSize(tam_c);
						if(tam_c == 0){
							servidores.push_back(*s);
							salvaCanais();
							s->null();
							for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
								carregaCanais(*it);
							}
							cntrl = 0;
							break;
						}
						cntrl++;
						break;
					case 7:
						if(tam_c == 0){
							servidores.push_back(*s);
							salvaCanais();
							s->null();
							for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
								carregaCanais(*it);
							}
							cntrl = 0;
							break;
						}
						tam_c--;
						nome = line;
						cntrl++;
						break;
					case 8:
						if(line == "TEXTO"){
							c = new CanalTexto;
						}
						else{
							c = new CanalVoz;
						}
						c->setNome(nome);
						cntrl++;
						break;
					case 9:
						tam_m = stoi(line, nullptr);
						c->setMessagesSize(tam_m);
						if(tam_m == 0){
							s->setCanal(c);
							if(tam_c == 0){
								servidores.push_back(*s);
								salvaCanais();
								s->null();
								for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
									carregaCanais(*it);
								}
								cntrl = 0;
							}
							else{
								cntrl = 7;
							}
							break;
						}
						cntrl++;
						break;
					case 10:
						if(tam_m == 0){
							s->setCanal(c);
							if(tam_c == 0){
								servidores.push_back(*s);
								salvaCanais();
								s->null();
								for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
									carregaCanais(*it);
								}
								cntrl = 0;
							}
							else{
								cntrl = 7;
							}
							break;
						}
						tam_m--;
						id = stoi(line, nullptr);
						m->setAutor(id);
						cntrl++;
						break;
					case 11:
						m->setData(line);
						cntrl++;
						break;
					case 12:
						m->setConteudo(line);
						c->setMessage(*m);
						m->null();
						
						if(tam_m != 0){
							cntrl = 10;
							break;
						}
				
						s->setCanal(c);
				
						if(tam_c != 0){
							cntrl = 7;
							break;
						}

						if((s->getNome() == "\0") || (s->getDonoId() == 0)){
							cout << "ERRO: Arquivo corrompido. Foram detectadas informações faltantes." << endl;
							return;
						}
				
						servidores.push_back(*s);
						salvaCanais();
						s->null();
						for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
							carregaCanais(*it);
						}
				
						cntrl = 0;
						break;
					default:
						break;
				}	
			}
		}
	}
	servers.close();
	delete s;
	delete m;
}

//---------------------------------------------------------------------

//construtor
Sistema::Sistema(){
	canalAtivo = new Canal;
	null = new Canal;
}

//---------------------------------------------------------------------

void Sistema::salvar(){
	salvarUsuarios();
	salvarServidores();
}

void Sistema::carregar(){
	carregarUsuarios();
	carregarServidores();
}

//---------------------------------------------------------------------

//retorna os usuários cadastrados
vector<Usuario> Sistema::getUsuarios(){
	return usuarios;
}

//retorna os servidores cadastrados
vector<Servidor> Sistema::getServidores(){
	return servidores;
}

//retorna o usuário ativo
Usuario Sistema::getUsuarioAtivo(){
	return usuarioAtivo;
}

//retorna o servidor ativo
Servidor Sistema::getServidorAtivo(){
	return servidorAtivo;
}

//retorna o canal ativo
Canal Sistema::getCanalAtivo(){
	return *canalAtivo;
}

//---------------------------------------------------------------------

//busca um usuário pelo ID
Usuario Sistema::searchById(int id){
	Usuario user;

	for (long unsigned int i = 0; i < usuarios.size(); i++){
		user = usuarios[i];
		if(user.getId() == id){
			return user;
		}
	}
	return user.null();
}

//verifica se o email de um usuário já foi cadastrado
bool Sistema::searchUser(Usuario user){
	vector<Usuario>::iterator it;

	for(it = usuarios.begin(); it != usuarios.end(); it++){
		if(it->getEmail() == user.getEmail()){
			return true;
		}
	}
	return false;
}

//verifica se já existe um servidor com aquele nome
bool Sistema::searchServer(Servidor server){
	vector<Servidor>::iterator it;

	for(it = servidores.begin(); it != servidores.end(); it++){
		if((it->getNome() == server.getNome()) && (it->getDonoId() == server.getDonoId())){
			return true;
		}
	}
	return false;
}

//---------------------------------------------------------------------

//adiciona um usuário 
ostringstream Sistema::createUser(vector<string> &stream, int &id){
	Usuario user;

	output.str("");

	user.newUser(stream, id);

	if(usuarios.empty() == true){
		usuarios.push_back(user);
		output << "Usuário criado com sucesso.";
		return output;
	}
	else{
		if(searchUser(user) == false){
			usuarios.push_back(user);
			output << "Usuário criado com sucesso.";
			return output;
		}
		else{
			output << "ERRO: Esse email já foi vinculado a outro usuário.";
			return output;
		}
	}
}

//adiciona um servidor
ostringstream Sistema::createServer(vector<string> &stream, int &id){
	Servidor server;
	
	output.str("");

	server.newServer(stream, id);

	if(servidorAtivo.getNome() == "\0"){
		if(servidores.empty() == true){
			servidores.push_back(server);
			output << "Servidor criado com sucesso.";
			return output;
		}
		else{
			if(searchServer(server) == false){
				servidores.push_back(server);
				output << "Servidor criado com sucesso.";
				return output;
			}
			else{
				output << "ERRO: Esse servidor já foi cadastrado.";
				return output;
			}
		}
	}
	else{
		output << "ERRO: Você precisa sair do servidor ativo para criar um novo.";
		return output;
	}
}

//criando um canal no servidor
ostringstream Sistema::createChannel(vector<string> &stream){
	output.str("");
	
	if(canalAtivo->getNome() != "\0"){
		output << "ERRO: Você precisa sair do canal ativo para criar outro.";
		return output;
	}

	if(servidorAtivo.getDonoId() == usuarioAtivo.getId()){
		output = servidorAtivo.newChannel(stream);	
		return output;
	}
	else{
		output << "ERRO: Este usuário não tem permissão para alterar este servidor.";
		return output;
	}
}

//---------------------------------------------------------------------

//efetua login
ostringstream Sistema::login(vector<string> stream){
	vector<Usuario>::iterator it;
	
	output.str("");

	for(it = usuarios.begin(); it != usuarios.end(); it++){
		if((it->getEmail() == stream[1]) && (it->getSenha() == stream[2])){
			usuarioAtivo = *it;
			output << "Logado como " << usuarioAtivo.getEmail();
			return output;
		}
	}
	output << "ERRO: Email ou senha incorretos.";
	return output;
}

//desconecta o usuário
ostringstream Sistema::disconnect(){
	output.str("");
	
	output << "Desconectando usuário " << usuarioAtivo.getEmail();
	usuarioAtivo.null();
	salvaCanais();
	servidorAtivo.null();
	for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
		carregaCanais(*it);
	}
	return output;
}

//---------------------------------------------------------------------

//insere uma descrição para o servidor
ostringstream Sistema::setDesc(vector<string> &stream){
	Servidor server;
	string desc = "\0";
	vector<string>::iterator it_st;
	vector<Servidor>::iterator it_se;

	output.str("");
	
	for(it_st = stream.begin()+2; it_st != stream.end(); it_st++){
		if(it_st == stream.begin()+2){
			desc = *it_st;
		}
		else{
			desc += " " + *it_st;
		}
	}

	for(it_se = servidores.begin(); it_se != servidores.end(); it_se++){
		if((it_se->getNome() == stream[1]) && (it_se->getDonoId() == usuarioAtivo.getId())){
			it_se->setDescricao(desc);
			output << "Descrição de " << it_se->getNome() << " alterada com sucesso.";
			return output;
		}
		else if((it_se->getNome() == stream[1]) && (it_se->getDonoId() != usuarioAtivo.getId())){
			output << "ERRO: Este usuário não tem permissão para alterar este servidor."; 
			return output;
		}
	}
	output << "ERRO: O servidor especificado não existe.";
	return output;
}

//insere um código de convite para o servidor
ostringstream Sistema::setCode(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;
	
	output.str("");

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			if(it->getDonoId() != usuarioAtivo.getId()){
				output << "ERRO: Este usuário não tem permissão para alterar este servidor.";
				return output;
			}
			else{
				if(stream.size() < 3){
					string temp = "\0";
					it->setCodigo(temp);
				}
				else{
					it->setCodigo(stream[2]);
				}
				output << "Código de convite do servidor " << it->getNome() << " foi alterado.";
				return output;
			}
		}
	}
	output << "ERRO: O servidor especificado não existe.";
	return output;
}

//---------------------------------------------------------------------

//lista os servidores cadastrados no sistema
ostringstream Sistema::listServers(){
	vector<Servidor>::iterator it;

	output.str("");
	
	if(servidores.empty() == true){
		multoutput << "ERRO: Nenhum servidor cadastrado.";
		return output;
	}

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getDonoId() == usuarioAtivo.getId()){
			output << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << "\n";
		}
		else{
			if(it->getCodigo() == "\0"){
				output << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << "\n";
			}
			for(vector<int>::iterator it_serv = it->getParticipantes().begin(); it_serv != it->getParticipantes().end(); it_serv++){
				if(*it_serv == usuarioAtivo.getId()){
					output << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << "\n";
				}
			}
		}
	}
	return output;
}

//listando os participantes de um servidor
ostringstream Sistema::listParticipants(){	
	Usuario user;
	vector<int> participantes = servidorAtivo.getParticipantes();
	vector<int>::iterator it;

	output.str("");
	
	for(it = participantes.begin(); it != participantes.end(); it++){
		user = searchById(*it);
		output << user.getNome() << " | " << user.getEmail() << "\n";
	}
	return output;
}

//listando os canais do servidor
ostringstream Sistema::listChannels(){
	output.str("");
	output = servidorAtivo.listChannels();
	return output;
}

//listando as mensagens enviadas
ostringstream Sistema::listMessages(){
	vector<Mensagem> mensagens = canalAtivo->getMensagens();
	vector<Mensagem>::iterator it;
	Usuario user;
	
	output.str("");

	if(mensagens.empty() == false){
		for(it = mensagens.begin(); it != mensagens.end(); it++){
			user = searchById(it->getAutor());
			output << user.getNome() << " [" << it->getData() << "]: " << it->getConteudo() << "\n";
			return output;
		}
	}
	else{
		output << "ERRO: Sem mensagens para exibir.";
		return output;
	}
}

//---------------------------------------------------------------------

//exclui um servidor do sistema
ostringstream Sistema::removeServer(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;
	
	output.str("");

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			if(it->getDonoId() == usuarioAtivo.getId()){
				servidores.erase(it);
				output << "Servidor " << stream[1] << " removido do sistema.";
				return output;
			}
			else{
				output << "ERRO: Este usuário não tem permissão para alterar este servidor.";
				return output;
			}
		}
	}
	output << "ERRO: Servidor " << stream[1] << " não foi encontrado.";
	return output;
}

//---------------------------------------------------------------------

//entra em um servidor
ostringstream Sistema::enterServer(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;
	vector<Canal> cpy;
	int i = 0;
	
	output.str("");

	if(servidorAtivo.getNome() != "\0"){
		output << "ERRO: Você já está conectado em outro servidor.";
		return output;
	}

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			//verifica se o usuário é dono do servidor
			if(it->getDonoId() == usuarioAtivo.getId()){
				output << usuarioAtivo.getNome() << " entrou no servidor com sucesso.";
				it->novoParticipante(usuarioAtivo);
				servidorAtivo = *it;
				carregaCanais(servidorAtivo);
				salvar();
				return output;
			}
			else{
				//verifica se o canal tem código de convite
				if(it->getCodigo() == "\0"){
					output << usuarioAtivo.getNome() << " entrou no servidor com sucesso.";
					it->novoParticipante(usuarioAtivo);
					servidorAtivo = *it;
					carregaCanais(servidorAtivo);
					salvar();
					return output;
				}
				else{
					if(stream.size() < 3){
						output << "ERRO: Servidor requer código de convite.";
						return output;
					}
					else{
						//verifica se o código passado é correto
						if(stream[2] == it->getCodigo()){
							output << usuarioAtivo.getNome() << " entrou no servidor com sucesso.";
							it->novoParticipante(usuarioAtivo);
							servidorAtivo = *it;
							carregaCanais(servidorAtivo);
							salvar();		
							return output;
						}
						else{
							output << "ERRO: Código de convite incorreto.";
							return output;
						}
					}
				}
			}
		}
		i++;
	}
	output << "ERRO: Servidor não cadastrado.";
	return output;
}

//entrando num canal
ostringstream Sistema::enterChannel(vector<string> &stream){
	int trigger = 0; //vai controlar se um canal já apareceu na busca. Se sim, trigger recebe 1.
	bool repetido = false; //vai controlar se existe mais de um canal com o nome passado
	vector<Canal *> canais = servidorAtivo.getCanais();
	
	output.str("");

	if(servidorAtivo.searchCanal(stream[1])->getNome() != "\0"){
		if(stream.size() < 3){
			for(vector<Canal *>::iterator it = canais.begin(); it != canais.end(); it++){
				//verifica se um nome passado pertence a mais de um canal e faz as devidas operações a partir disso
				if(trigger == 0){
					if((*it)->getNome() == stream[1]){
						trigger = 1;
					}
				}
				else{
					if((*it)->getNome() == stream[1]){
						repetido = true;
					}
				}
			}
			if(repetido == true){
				output << "ERRO: Existe mais de um canal com este nome. Especifique o tipo do canal que você quer alterar.";
				return output;
			}
			canalAtivo = servidorAtivo.searchCanal(stream[1]);
			output << "Entrando no canal \'" << canalAtivo->getNome() << "\'.";
			return output;
		}
		else{
			canalAtivo = servidorAtivo.searchCanal(stream[1], stream[2]);
			if(canalAtivo->getNome() != "\0"){ //se o retorno for "tipo inválido", não vai imprimir que está entrando no canal
				output << "Entrando no canal \'" << canalAtivo->getNome() << "\'.";
				return output;
			}
		}
	}
	else{
		output << "ERRO: Canal \'" << stream[1] << "\' não existe.";
		return output;
	}
}

//---------------------------------------------------------------------

//saindo do servidor
ostringstream Sistema::leaveServer(){
	vector<Canal *> c;
	
	output.str("");

	c.push_back(nullptr);

	if(servidorAtivo.getNome() == "\0"){
		output << "ERRO: Nenhum servidor ativo.";
		return output;
	}
	else{
		output << "Saindo do servidor " << servidorAtivo.getNome();
		salvaCanais();
		servidorAtivo.null();
		for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
			carregaCanais(*it);
		}
	}
	return output;
}

//saindo de um canal
ostringstream Sistema::leaveChannel(){
	output.str("");
	
	if(canalAtivo->getNome() != "\0"){
		output << "Saindo do canal \'" << canalAtivo->getNome() << "\'.";
		canalAtivo = null;
		return output;
	}
	else{
		output << "ERRO: Nenhum canal ativo.";
	}
	return output;
}

//---------------------------------------------------------------------

//enviando uma mensagem
ostringstream Sistema::sendMessage(vector<string> &stream){
	output.str("");
	
	string mensagem = stream[1];
	

	//juntando  a mensagem
	for(long unsigned int i = 2; i < stream.size(); i++){
		mensagem += " " + stream[i];
	}

	canalAtivo->newMessage(mensagem, usuarioAtivo.getId());
	
	output << "Mensagem enviada.";
	return output;
}

//---------------------------------------------------------------------

//salva os canais de um servidor antes de serem anulados no leave-server
void Sistema::salvaCanais(){
	bool ja_tem = false;

	if(servidorAtivo.getCanais().empty() == false){
		for(vector<string>::iterator it = index.begin(); it != index.end(); it++){
			if(*it == servidorAtivo.getNome()){
				ja_tem = true;
				break;
			}
		}
		if(ja_tem == false){
			canais.push_back(servidorAtivo.getCanais());
			index.push_back(servidorAtivo.getNome());
		}
	}
}

//carrega os canais de um servidor ao ser ativado pelo enter-server
void Sistema::carregaCanais(Servidor &serv){
	for(long unsigned int i = 0; i < index.size(); i++){
		if(index.at(i) == serv.getNome()){
			serv.setCanais(canais.at(i));
			return;
		}
	}
}

//---------------------------------------------------------------------

//destrutor
Sistema::~Sistema(){
}