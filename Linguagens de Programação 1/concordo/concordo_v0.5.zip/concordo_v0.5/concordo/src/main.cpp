//Para maiores esclarecimentos de dúvidas sobre o código, consultar o README.md.

#include <iostream> //Entrada e saída do usuário
#include <string> //Implementação do tipo string
#include <sstream> //Implementação do tipo ostringstream para exibir mensagens na tela
#include <cstring> //Uso da função substr
#include <cstdlib> //Limpeza a tela do terminal
#include <vector> //Importação do módulo de vetores STL
#include "usuario.hpp" //Implementação da classe Usuario
#include "servidor.hpp" //Implementação da classe Servidor
#include "sistema.hpp" //Implementação da classe Sistema

using namespace std;

int main(int argc, char const *argv[]){
	Sistema sistema; //Sistema que vai gerenciar toda a execução do programa.
	Usuario user; //Usuário que controlará a "liberação" de alguns comandos.
	Servidor server; //Servidor que controlará a "liberação" de alguns comandos.
	Canal channel; //Canal que controlará a "liberação" de alguns comandos.
	int id = 1; //Inteiro que determinará o id de cada usuário.

	ostringstream output;
	string input; //String que vai receber a entrada do usuário.
	vector<string> stream; //Vetor de string que vai armazenar a divisão da string de entrada em comando e parâmetros.
	string comandos[18] = {"quit", "create-user", "login", "disconnect", "create-server", "set-server-desc", "set-server-invite-code", "list-servers", "remove-server", "enter-server", "leave-server", "list-participants", "list-channels", "create-channel", "enter-channel", "leave-channel", "send-message", "list-messages"}; //Array com os identificadores de comandos válidos do sistema.

	system("clear");
	if(sistema.getUsuarios().empty() == false){
		id = (int)sistema.getUsuarios().size() + 1;
	}

	//Executando o programa
	do{ //Loop que vai se repetir enquando o usuário não digitar o comando 'quit'.
		
		sistema.carregar();
		output.str("");
		
		//Capturando o comando digitado
		cout << "> "; //Só pra melhorar visualmente o programa.
		cin.ignore(0);
		getline(cin, input);

		//Fazendo a divisão da string de entrada
		size_t start = 0, end = 0;
		while((end = input.find(' ', start)) != string::npos){
			stream.push_back(input.substr(start, (end - start)));
			start = end + 1;
		}
		stream.push_back(input.substr(start));

		//Decisão do que fazer a partir do comando digitado pelo usuário
		//Comando 'quit'
		if(stream[0] == comandos[0]){
			cout << "Saindo do Concordo\n" << endl;
			sistema.salvar();
			return 0;
		}
		//Comando 'create-user'
		else if(stream[0] == comandos[1]){
			output = sistema.createUser(stream, id);
			id++;
			sistema.salvar();
			cout << output << endl;
		}
		//Comando 'login'
		else if(stream[0] == comandos[2]){
			if(stream.size() >= 3){ //O usuário precisa do identificador do comando, e de um email e senha cadastrados previamente pro login funcionar.
				if(sistema.getUsuarios().empty() == false){ //Para o login funcionar, pelo menos um usuário precisa ter sido criado.
					output = sistema.login(stream);
					cout << output << endl;
				}
				else{
					cout << "ERRO: Nenhum usuário cadastrado." << endl;
				}
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'disconnect'
		else if(stream[0] == comandos[3]){
			user = sistema.getUsuarioAtivo();
			if(user.getNome() != "\0"){ //Verifica se tem algum usuário logado.
				output = sistema.disconnect();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Nenhum usuário logado." << endl;
			}
		}
		//Comando 'create-server'
		else if(stream[0] == comandos[4]){
			if(stream.size() >= 2){ //O comando precisa do identificador do comando e do nome do servidor a ser criado para estar completo.
				int id;
				user = sistema.getUsuarioAtivo();
				if(user.getNome() != "\0"){ //Verifica se tem algum usuário logado.
					id = sistema.getUsuarioAtivo().getId();
					output = sistema.createServer(stream, id);
					sistema.salvar();
					cout << output << endl;
				}
				else{
					cout << "ERRO: Nenhum usuário logado." << endl;
				}
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'set-server-desc'
		else if(stream[0] == comandos[5]){
			if(stream.size() >= 3){ //O comando precisa do identificador do comando, nome do servidor e a descrição para estar completo.
				user = sistema.getUsuarioAtivo();
				if(user.getNome() != "\0"){ //Verifica se tem usuário logado.
					output = sistema.setDesc(stream);
					sistema.salvar();
					cout << output << endl;
				}
				else{
					cout << "ERRO: Nenhum servidor ativo." << endl;
				}
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'set-server-invite-code'
		else if(stream[0] == comandos[6]){
			if(stream.size() >= 2){ //O comando precisa do identificador do comando e do nome do servidor para estar completo. O código é opcional.
				user = sistema.getUsuarioAtivo();
				if(user.getNome() != "\0"){ //Verifica se tem usuário logado.
					output = sistema.setCode(stream);
					sistema.salvar();
					cout << output << endl;
				}
				else{
					cout << "ERRO: Nenhum servidor ativo." << endl;
				}
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'list-servers'
		else if(stream[0] == comandos[7]){
			output = sistema.listServers();
			cout << output << endl;
		}
		//Comando 'remove-server'
		else if(stream[0] == comandos[8]){
			if(stream.size() >= 2){ //O comando precisa do identificador do comando e do nome do servidor para estar completo.
				output = sistema.removeServer(stream);
				sistema.salvar();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'enter-server'
		else if(stream[0] == comandos[9]){
			if(stream.size() >= 2){ //O comando precisa do identificador do comando e do nome do servidor para estar completo. A necessidade do parâmetro código varia de servidor para servidor.
				user = sistema.getUsuarioAtivo();
				if(user.getNome() != "\0"){ //Verifica se tem usuário logado.
					output = sistema.enterServer(stream);
					sistema.salvar();
					cout << output << endl;
				}
				else{
					cout << "ERRO: Nenhum usuário logado." << endl;
				}
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'leave-server'
		else if(stream[0] == comandos[10]){
			server = sistema.getServidorAtivo();
			if(sistema.searchServer(server) == true){ //Verifica se tem servidor ativo.
				output = sistema.leaveServer();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Nenhum servidor ativo." << endl;
			}
		}
		//Comando 'list-participants'
		else if(stream[0] == comandos[11]){
			server = sistema.getServidorAtivo();
			if(sistema.searchServer(server) == true){ //Verifica se tem servidor ativo.
				output = sistema.listParticipants();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Nenhum servidor ativo." << endl;
			}
		}
		//Comando 'list-channels'
		else if(stream[0] == comandos[12]){
			server = sistema.getServidorAtivo();
			if(sistema.searchServer(server) == true){ //Verifica se tem servidor ativo.
				output = sistema.getServidorAtivo().listChannels();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Nenhum servidor ativo." << endl;
			}
		}
		//Comando 'create-channel'
		else if(stream[0] == comandos[13]){
			server = sistema.getServidorAtivo();
			if(sistema.searchServer(server) == true){ //Verifica se tem servidor ativo.
				output = sistema.createChannel(stream);
				sistema.salvar();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Nenhum servidor ativo." << endl;
			}
		}
		//Comando 'enter-channel'
		else if(stream[0] == comandos[14]){
			if(stream.size() >= 2){ //Verifica se o comando foi passado completo
				server = sistema.getServidorAtivo();
				if(sistema.searchServer(server) == true){ //Verifica se tem servidor ativo.
					output = sistema.enterChannel(stream);
					cout << output << endl;
				}
				else{
					cout << "ERRO: Nenhum servidor ativo." << endl;
				}
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'leave-channel'
		else if(stream[0] == comandos[15]){
			channel = sistema.getCanalAtivo();
			if(channel.getNome() != "\0"){ //Verifica se tem canal ativo.
				output = sistema.leaveChannel();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Nenhum canal ativo." << endl;
			}
		}
		//Comando 'send-message'
		else if(stream[0] == comandos[16]){
			if(stream.size() >= 2){ //Verifica se o comando foi passado completo
				channel = sistema.getCanalAtivo();
				if(channel.getNome() != "\0"){ //Verifica se tem canal ativo.
					output = sistema.sendMessage(stream);
					sistema.salvar();
					cout << output << endl;
				}
				else{
					cout << "ERRO: Nenhum canal ativo." << endl;
				}
			}
			else{
				cout << "ERRO: Comando incompleto." << endl;
			}
		}
		//Comando 'list-messages'
		else if(stream[0] == comandos[17]){
			channel = sistema.getCanalAtivo();
			if(channel.getNome() != "\0"){ //Verifica se tem canal ativo.
				output = sistema.listMessages();
				cout << output << endl;
			}
			else{
				cout << "ERRO: Nenhum canal ativo." << endl;
			}
		}
		else{
			cout << "ERRO: Comando inválido." << endl;
		}

		stream.clear(); //Limpa o vetor que recebeu comando e parâmetros para a próxima execução do loop.
		
		cout << endl; //Só pra melhorar visualmente o programa,
	}while(stream[0] != "quit");
}