#ifndef _SERVIDOR_HPP_
#define _SERVIDOR_HPP_

#include <string>
#include <vector>
#include "canal.hpp"
#include "usuario.hpp"

using namespace std;

class Servidor{
		int usuarioDonoId;
		string nome, descricao, codigoConvite;
		vector<Canal *> canais;
		vector<int> participantesIDs;
	public:
		Servidor();
		//---------------------------------------------------------------------
		void setDonoId(int id); //
		void setNome(string s); //
		void setDescricao(string &desc);
		void setCodigo(string &codigo);
		void setParticipantesSize(int tam); //
		void setParticipantes(int id); //
		void setCanaisSize(int tam); //
		void setCanal(Canal *c); //
		void setCanais(vector<Canal *> &serv_canais);
		//---------------------------------------------------------------------
		int getDonoId();
		string getNome();
		string getDescricao();
		string getCodigo();
		vector<Canal *> getCanais();
		vector<int> getParticipantes();
		//---------------------------------------------------------------------
		vector<Canal *> canaisCopy();
		//---------------------------------------------------------------------
		void newServer(vector<string> &stream, int &id);
		void novoParticipante(Usuario &user);
		ostringstream newChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		ostringstream listChannels();
		//---------------------------------------------------------------------
		Canal * searchCanal(string &nome, string tipo = "\0");
		//---------------------------------------------------------------------
		Servidor null();
		//---------------------------------------------------------------------
		~Servidor();
};

#endif