#ifndef _SISTEMA_HPP_
#define _SISTEMA_HPP_

#include <vector>
#include <string>
#include <sstream>
#include "usuario.hpp"
#include "servidor.hpp"
#include "mensagem.hpp"
#include "canal.hpp"

using namespace std;

class Sistema{
		vector<Usuario> usuarios;
		vector<Servidor> servidores;
		vector<vector<Canal *>> canais;
		vector<string> index;
		Usuario usuarioAtivo;
		Servidor servidorAtivo;
		Canal *canalAtivo;
		Canal *null;
		ostringstream output(ostringstream::ate);

		void salvarUsuarios();
		void salvarServidores();
		void carregarUsuarios();
		void carregarServidores();
	public:
		Sistema();
		//---------------------------------------------------------------------
		void salvar();
		void carregar();
		//---------------------------------------------------------------------
		vector<Usuario> getUsuarios();
		vector<Servidor> getServidores();
		Usuario getUsuarioAtivo();
		Servidor getServidorAtivo();
		Canal getCanalAtivo();
		//---------------------------------------------------------------------
		Usuario searchById(int id);
		bool searchUser(Usuario user);
		bool searchServer(Servidor server);
		//---------------------------------------------------------------------
		ostringstream createUser(vector<string> &stream, int &sid);
		ostringstream createServer(vector<string> &stream, int &id);
		ostringstream createChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		ostringstream login(vector<string> stream);
		ostringstream disconnect();
		//---------------------------------------------------------------------
		ostringstream setDesc(vector<string> &stream);
		ostringstream setCode(vector<string> &stream);
		//---------------------------------------------------------------------
		ostringstream listServers();
		ostringstream listParticipants();
		ostringstream listChannels();
		ostringstream listMessages();
		//---------------------------------------------------------------------
		ostringstream removeServer(vector<string> &stream);
		//---------------------------------------------------------------------
		ostringstream enterServer(vector<string> &stream);
		ostringstream enterChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		ostringstream leaveServer();
		ostringstream leaveChannel();
		//---------------------------------------------------------------------
		ostringstream sendMessage(vector<string> &stream);
		//---------------------------------------------------------------------
		void salvaCanais();
		void carregaCanais(Servidor &serv);
		//---------------------------------------------------------------------
		~Sistema();
};

#endif