#ifndef _MENSAGEM_HPP_
#define _MENSAGEM_HPP_

#include <string>

using namespace std;

class Mensagem{
		string dataHora, conteudo;
		int enviadaPor;
	public:
		Mensagem();
		//---------------------------------------------------------------------
		string getData();
		string getConteudo();
		int getAutor();
		//---------------------------------------------------------------------
		void setAutor(int &id);
		void setData(string &data);
		void setConteudo(string &cont);
		//---------------------------------------------------------------------
		Mensagem newMessage(string &mensagem, int &autor);
		//---------------------------------------------------------------------
		Mensagem null();
		//---------------------------------------------------------------------
		~Mensagem();
};

#endif