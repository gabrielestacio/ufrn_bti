#include <string>
#include <ctime>
#include "mensagem.hpp"

using namespace std;

//construtor
Mensagem::Mensagem(){
}

//---------------------------------------------------------------------

//retorna a data e hora que a mensagem foi enviada
string Mensagem::getData(){
	return dataHora;
}

//retorna o conteúdo da mensagem
string Mensagem::getConteudo(){
	return conteudo;
}

//retorna o autor da mensagem
int Mensagem::getAutor(){
	return enviadaPor;
}

//---------------------------------------------------------------------

//cria uma nova mensagem
Mensagem Mensagem::newMessage(string &mensagem, int &autor){
	time_t t;
	tm *data;
	int horario[5] = {};

	conteudo = mensagem;
	enviadaPor = autor;

	t = time(nullptr);
	data = localtime(&t);
	
	horario[0] = data->tm_mday;
	horario[1] = data->tm_mon + 1;
	horario[2] = data->tm_year + 1900;
	horario[3] = data->tm_hour;
	horario[4] = data->tm_min;

	dataHora = to_string(horario[0]) + "/" + to_string(horario[1]) + "/" + to_string(horario[2]) + " - " + to_string(horario[3]) + ":" + to_string(horario[4]);
	
	return *this;
}

//---------------------------------------------------------------------

//torna nulo o valor de uma mensagem
Mensagem Mensagem::null(){
	dataHora = "\0";
	conteudo = "\0";
	enviadaPor = 0;

	return *this;
}

//---------------------------------------------------------------------

//destrutor
Mensagem::~Mensagem(){
}