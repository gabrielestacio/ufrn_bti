#include <vector>
#include <iostream>
#include <string>
#include <fstream>
#include "canal.hpp"
#include "mensagem.hpp"
#include "usuario.hpp"
#include "servidor.hpp"
#include "sistema.hpp"

using namespace std;

void Sistema::salvarUsuarios(){
	ofstream users;

	if(usuarios.empty()){
		return;
	}
	else{
		users.open("usuarios.txt");
		users << usuarios.size() << endl;
		for(vector<Usuario>::iterator it = usuarios.begin(); it != usuarios.end(); it++){
			users << it->getId() << endl;
			users << it->getNome() << endl;
			users << it->getEmail() << endl;
			users << it->getSenha() << endl;
		}
		users.close();
	}
}

void Sistema::salvarServidores(){
	ofstream servers;

	if(servidores.empty()){
		return;
	}
	else{
		servers.open("servidores.txt");
		servers << servidores.size() << endl;
		for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
			servers << it->getDonoId() << endl;
			servers << it->getNome() << endl;
			servers << it->getDescricao() << endl;
			servers << it->getCodigo() << endl;
			servers << it->getParticipantes().size() << endl;
			if(it->getParticipantes().empty() != true){
				for(long unsigned int i = 0; i < it->getParticipantes().size(); i++){
					servers << it->getParticipantes().at(i) << endl;
				}
			}
			else{
				servers << endl;
			}
			servers << it->getCanais().size() << endl;
			for(vector<Canal *>::iterator it_c = it->getCanais().begin(); it_c != it->getCanais().end(); it_c++){
				//servers << (*it_c)->getNome() << endl;
				/*if((*it_c)->getType() == 1){
					servers << "TEXTO" << endl;	
				}
				else if((*it_c)->getType() == 2){
					servers << "VOZ" << endl;	
				}
				servers << (*it_c)->getMensagens().size();
				for(vector<Mensagem>::iterator it_m = (*it_c)->getMensagens().begin(); it_m != (*it_c)->getMensagens().end(); it_m++){
					servers << it_m->getAutor() << endl;
					servers << it_m->getData() << endl;
					servers << it_m->getConteudo() << endl;
				}*/
			}
		}
		servers.close();
	}
}

void Sistema::carregarUsuarios(){
	/*ifstream users;
	long unsigned int tamanho;
	int inteiros;
	string strings;

	users.open("usuarios.txt");
	while(users >> *this){
		getline(users, tamanho);
		usuarios.reserve(tamanho);
		for(vector<Usuario>::iterator it_u = usuarios.begin(); it_u != usuarios.end(); it_u++){
			getline(users, inteiros);
			it_u->setId(inteiros);
			getline(users, strings);
			it_u->setNome(strings);
			getline(users, strings);
			it_u->setEmail(strings);
			getline(users, strings);
			it_u->setSenha(strings);
		}
	}
	users.close();*/
}

void Sistema::carregarServidores(){
	/*ifstream servers;
	long unsigned int tamanho;
	int inteiros;
	string strings;

	servers.open("servidores.txt");
	while(servers >> *this){
		getline(servers, tamanho);
		servidores.reserve(tamanho);
		for(vector<Servidor>::iterator it_s = servidores.begin(); it_s != servidores.end(); it_s++){
			getline(servers, inteiros);
			it_s->setDonoId(inteiros);
			getline(servers, strings);
			it_s->setNome(strings);
			getline(servers, strings);
			it_s->setDesc(strings);
			getline(servers, strings);
			it_s->setCodigo(strings);
			getline(servers, inteiros);
			it_s->setParticipantesSize(inteiros);
			for(vector<int>::iterator it_p = it_s->getParticipantes().begin(); it_p != it_s->getParticipantes().end(); it_p++){
				getline(servers, inteiros);
				it_p->setParticipantes(inteiros);
			}
			getline(servers, inteiros);
			it_s->setCanaisSize(inteiros);
			for(vector<Canal *>::iterator it_c = it_s->getCanais().begin(); it_c != it_s->getCanais().end(); it_c++){
				getline(servers, strings);
				//Como garantir que esse canal vai ser criado com o tipo certo?
				(*it_c)->setNome(strings);
			}
		}
	}
	servers.close();*/
}

//---------------------------------------------------------------------

//construtor
Sistema::Sistema(){
	canalAtivo = new Canal;
	null = new Canal;
}

//---------------------------------------------------------------------

void Sistema::salvar(){
	salvarUsuarios();
	salvarServidores();
}

void Sistema::carregar(){
	carregarUsuarios();
	carregarServidores();
}

//---------------------------------------------------------------------

//retorna os usuários cadastrados
vector<Usuario> Sistema::getUsuarios(){
	return usuarios;
}

//retorna os servidores cadastrados
vector<Servidor> Sistema::getServidores(){
	return servidores;
}

//retorna o usuário ativo
Usuario Sistema::getUsuarioAtivo(){
	return usuarioAtivo;
}

//retorna o servidor ativo
Servidor Sistema::getServidorAtivo(){
	return servidorAtivo;
}

//retorna o canal ativo
Canal Sistema::getCanalAtivo(){
	return *canalAtivo;
}

//---------------------------------------------------------------------

//busca um usuário pelo ID
Usuario Sistema::searchById(int id){
	Usuario user;

	for (long unsigned int i = 0; i < usuarios.size(); i++){
		user = usuarios[i];
		if(user.getId() == id){
			return user;
		}
	}
	return user.null();
}

//verifica se o email de um usuário já foi cadastrado
bool Sistema::searchUser(Usuario user){
	vector<Usuario>::iterator it;

	for(it = usuarios.begin(); it != usuarios.end(); it++){
		if(it->getEmail() == user.getEmail()){
			return true;
		}
	}
	return false;
}

//verifica se já existe um servidor com aquele nome
bool Sistema::searchServer(Servidor server){
	vector<Servidor>::iterator it;

	for(it = servidores.begin(); it != servidores.end(); it++){
		if((it->getNome() == server.getNome()) && (it->getDonoId() == server.getDonoId())){
			return true;
		}
	}
	return false;
}

//---------------------------------------------------------------------

//adiciona um usuário 
void Sistema::createUser(vector<string> &stream, int &id){
	Usuario user;
	//vector<string> copy = stream;

	user.newUser(stream, id);

	if(usuarios.empty() == true){
		usuarios.push_back(user);
		cout << "Usuário criado com sucesso." << endl;
		salvar();
	}
	else{
		if(searchUser(user) == false){
			usuarios.push_back(user);
			cout << "Usuário criado com sucesso." << endl;
			salvar();
		}
		else{
			cout << "ERRO: Esse email já foi vinculado a outro usuário." << endl;
		}
	}
}

//adiciona um servidor
void Sistema::createServer(vector<string> &stream, int &id){
	Servidor server;

	server.newServer(stream, id);

	if(servidorAtivo.getNome() == "\0"){
		if(servidores.empty() == true){
			servidores.push_back(server);
			cout << "Servidor criado com sucesso." << endl;
			salvar();
		}
		else{
			if(searchServer(server) == false){
				servidores.push_back(server);
				cout << "Servidor criado com sucesso." << endl;
				salvar();
			}
			else{
				cout << "ERRO: Esse servidor já foi cadastrado." << endl;
			}
		}
	}
	else{
		cout << "ERRO: Você precisa sair do servidor ativo para criar um novo." << endl;
	}
}

//criando um canal no servidor
void Sistema::createChannel(vector<string> &stream){
	if(canalAtivo->getNome() != "\0"){
		cout << "ERRO: Você precisa sair do canal ativo para criar outro." << endl;
		return;
	}

	if(servidorAtivo.getDonoId() == usuarioAtivo.getId()){
		servidorAtivo.newChannel(stream);	
		salvar();
	}
	else{
		cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl;
	}
}

//---------------------------------------------------------------------

//efetua login
void Sistema::login(vector<string> stream){
	vector<Usuario>::iterator it;

	for(it = usuarios.begin(); it != usuarios.end(); it++){
		if((it->getEmail() == stream[1]) && (it->getSenha() == stream[2])){
			usuarioAtivo = *it;
			cout << "Logado como " << usuarioAtivo.getEmail() << endl;
			return;
		}
	}
	cout << "ERRO: Email ou senha incorretos." << endl;
}

//desconecta o usuário
void Sistema::disconnect(){
	cout << "Desconectando usuário " << usuarioAtivo.getEmail() << endl;
	usuarioAtivo.null();
	/*canalAtivo->null();
	salvaCanais();
	servidorAtivo.null();*/
}

//---------------------------------------------------------------------

//insere uma descrição para o servidor
void Sistema::setDesc(vector<string> &stream){
	Servidor server;
	string desc = "\0";
	vector<string>::iterator it_st;
	vector<Servidor>::iterator it_se;

	for(it_st = stream.begin()+2; it_st != stream.end(); it_st++){
		if(it_st == stream.begin()+2){
			desc = *it_st;
		}
		else{
			desc += " " + *it_st;
		}
	}

	for(it_se = servidores.begin(); it_se != servidores.end(); it_se++){
		if((it_se->getNome() == stream[1]) && (it_se->getDonoId() == usuarioAtivo.getId())){
			it_se->setDescricao(desc);
			cout << "Descrição de " << it_se->getNome() << " alterada com sucesso." << endl;
			salvar();
			return;
		}
		else if((it_se->getNome() == stream[1]) && (it_se->getDonoId() != usuarioAtivo.getId())){
			cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl; 
			return;
		}
	}
	cout << "ERRO: O servidor especificado não existe." << endl;
}

//insere um código de convite para o servidor
void Sistema::setCode(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			if(it->getDonoId() != usuarioAtivo.getId()){
				cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl;
				return;
			}
			else{
				if(stream.size() < 3){
					string temp = "\0";
					it->setCodigo(temp);
					salvar();
				}
				else{
					it->setCodigo(stream[2]);
					salvar();
				}
				cout << "Código de convite do servidor " << it->getNome() << " foi alterado." << endl;
				return;
			}
		}
	}
	cout << "ERRO: O servidor especificado não existe." << endl;
}

//---------------------------------------------------------------------

//lista os servidores cadastrados no sistema
void Sistema::listServers(){
	vector<Servidor>::iterator it;

	if(servidores.empty() == true){
		cout << "ERRO: Nenhum servidor cadastrado." << endl;
		return;
	}

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getDonoId() == usuarioAtivo.getId()){
			cout << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << endl;
		}
		else{
			if(it->getCodigo() == "\0"){
				cout << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << endl;
			}
			for(vector<int>::iterator it_serv = it->getParticipantes().begin(); it_serv != it->getParticipantes().end(); it_serv++){
				if(*it_serv == usuarioAtivo.getId()){
					cout << "Nome: " << it->getNome() << " | Descrição: " << it->getDescricao() << " | Código: " << it->getCodigo() << endl;
				}
			}
		}
	}
}

//listando os participantes de um servidor
void Sistema::listParticipants(){	
	Usuario user;
	vector<int> participantes = servidorAtivo.getParticipantes();
	vector<int>::iterator it;

	for(it = participantes.begin(); it != participantes.end(); it++){
		user = searchById(*it);
		cout << user.getNome() << " | " << user.getEmail() << endl;
		/*if(user.getNome() != "\0"){
		}*/
	}
}

//listando os canais do servidor
void Sistema::listChannels(){
	servidorAtivo.listChannels();
}

//listando as mensagens enviadas
void Sistema::listMessages(){
	vector<Mensagem> mensagens = canalAtivo->getMensagens();
	vector<Mensagem>::iterator it;
	Usuario user;

	if(mensagens.empty() == false){
		for(it = mensagens.begin(); it != mensagens.end(); it++){
			user = searchById(it->getAutor());
			cout << user.getNome() << " [" << it->getData() << "]: " << it->getConteudo() << endl;
		}
	}
	else{
		cout << "ERRO: Sem mensagens para exibir." << endl;
	}
}

//---------------------------------------------------------------------

//exclui um servidor do sistema
void Sistema::removeServer(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			if(it->getDonoId() == usuarioAtivo.getId()){
				servidores.erase(it);
				cout << "Servidor " << stream[1] << " removido do sistema." << endl;
				salvar();
				return;
			}
			else{
				cout << "ERRO: Este usuário não tem permissão para alterar este servidor." << endl;
				return;
			}
		}
	}
	cout << "ERRO: Servidor " << stream[1] << " não foi encontrado." << endl;
}

//---------------------------------------------------------------------

//entra em um servidor
void Sistema::enterServer(vector<string> &stream){
	Servidor server;
	vector<Servidor>::iterator it;
	vector<Canal> cpy;
	int i = 0;

	if(servidorAtivo.getNome() != "\0"){
		cout << "ERRO: Você já está conectado em outro servidor." << endl;
		return;
	}

	for(it = servidores.begin(); it != servidores.end(); it++){
		if(it->getNome() == stream[1]){
			//verifica se o usuário é dono do servidor
			if(it->getDonoId() == usuarioAtivo.getId()){
				cout << usuarioAtivo.getNome() << " entrou no servidor com sucesso." << endl;
				it->novoParticipante(usuarioAtivo);
				//salvar();
				servidorAtivo = *it;
				carregaCanais(servidorAtivo);
				salvar();
			}
			else{
				//verifica se o canal tem código de convite
				if(it->getCodigo() == "\0"){
					cout << usuarioAtivo.getNome() << " entrou no servidor com sucesso." << endl;
					it->novoParticipante(usuarioAtivo);
					//salvar();
					servidorAtivo = *it;
					carregaCanais(servidorAtivo);
					salvar();
				}
				else{
					if(stream.size() < 3){
						cout << "ERRO: Servidor requer código de convite." << endl;
					}
					else{
						//verifica se o código passado é correto
						if(stream[2] == it->getCodigo()){
							cout << usuarioAtivo.getNome() << " entrou no servidor com sucesso." << endl;
							it->novoParticipante(usuarioAtivo);
							//salvar();
							servidorAtivo = *it;
							carregaCanais(servidorAtivo);		
							salvar();
						}
						else{
							cout << "ERRO: Código de convite incorreto." << endl;
						}
					}
				}
			}
			return;
		}
		i++;
	}
	cout << "ERRO: Servidor não cadastrado." << endl;
}

//entrando num canal
void Sistema::enterChannel(vector<string> &stream){
	int trigger = 0; //vai controlar se um canal já apareceu na busca. Se sim, trigger recebe 1.
	bool repetido = false; //vai controlar se existe mais de um canal com o nome passado
								salvar();
	vector<Canal *> canais = servidorAtivo.getCanais();

	if(servidorAtivo.searchCanal(stream[1])->getNome() != "\0"){
		if(stream.size() < 3){
			for(vector<Canal *>::iterator it = canais.begin(); it != canais.end(); it++){
				//verifica se um nome passado pertence a mais de um canal e faz as devidas operações a partir disso
				if(trigger == 0){
					if((*it)->getNome() == stream[1]){
						trigger = 1;
					}
				}
				else{
					if((*it)->getNome() == stream[1]){
						repetido = true;
					}
				}
			}
			if(repetido == true){
				cout << "ERRO: Existe mais de um canal com este nome. Especifique o tipo do canal que você quer alterar." << endl;
				return;
			}
			canalAtivo = servidorAtivo.searchCanal(stream[1]);
			cout << "Entrando no canal \'" << canalAtivo->getNome() << "\'." << endl;
		}
		else{
			canalAtivo = servidorAtivo.searchCanal(stream[1], stream[2]);
			if(canalAtivo->getNome() != "\0"){ //se o retorno for "tipo inválido", não vai imprimir que está entrando no canal
				cout << "Entrando no canal \'" << canalAtivo->getNome() << "\'." << endl;
			}
		}
	}
	else{
		cout << "ERRO: Canal \'" << stream[1] << "\' não existe." << endl;
	}
}

//---------------------------------------------------------------------

//saindo do servidor
void Sistema::leaveServer(){
	vector<Canal *> c;

	c.push_back(nullptr);

	if(servidorAtivo.getNome() == "\0"){
		cout << "ERRO: Nenhum servidor ativo." << endl;
	}
	else{
		cout << "Saindo do servidor " << servidorAtivo.getNome() << endl;
		salvaCanais();
		servidorAtivo.null();
		for(vector<Servidor>::iterator it = servidores.begin(); it != servidores.end(); it++){
			carregaCanais(*it);
		}
	}
}

//saindo de um canal
void Sistema::leaveChannel(){
	if(canalAtivo->getNome() != "\0"){
		cout << "Saindo do canal \'" << canalAtivo->getNome() << "\'." << endl;
		canalAtivo = null;
	}
	else{
		cout << "ERRO: Nenhum canal ativo." << endl;
	}
}

//---------------------------------------------------------------------

//enviando uma mensagem
void Sistema::sendMessage(vector<string> &stream){
	string mensagem = stream[1];

	//juntando  a mensagem
	for(long unsigned int i = 2; i < stream.size(); i++){
		mensagem += " " + stream[i];
	}

	canalAtivo->newMessage(mensagem, usuarioAtivo.getId());
	salvar();
}

//---------------------------------------------------------------------

//salva os canais de um servidor antes de serem anulados no leave-server
void Sistema::salvaCanais(){
	bool ja_tem = false;
	if(servidorAtivo.getCanais().empty() == false){
		for(vector<string>::iterator it = index.begin(); it != index.end(); it++){
			if(*it == servidorAtivo.getNome()){
				ja_tem = true;
				break;
			}
		}
		if(ja_tem == false){
			canais.push_back(servidorAtivo.getCanais());
			index.push_back(servidorAtivo.getNome());
		}
	}
}

//carrega os canais de um servidor ao ser ativado pelo enter-server
void Sistema::carregaCanais(Servidor &serv){
	for(long unsigned int i = 0; i < index.size(); i++){
		if(index.at(i) == serv.getNome()){
			serv.setCanais(canais.at(i));
			return;
		}
	}
}

//---------------------------------------------------------------------

//destrutor
Sistema::~Sistema(){
}