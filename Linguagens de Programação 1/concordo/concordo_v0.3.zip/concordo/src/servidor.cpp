#include "servidor.hpp"
#include "canal.hpp"
#include "usuario.hpp"
#include "sistema.hpp"
#include <iostream>
#include <string>
#include <vector>

using namespace std;

//construtor
Servidor::Servidor(){
}

//---------------------------------------------------------------------

//insere a descrição do servidor
void Servidor::setDescricao(string &desc){
	descricao = desc;
}

//insere o código de convite do servidor
void Servidor::setCodigo(string &codigo){
	codigoConvite = codigo;
}

//insere os canais do servidor ativo
void Servidor::setCanais(vector<Canal *> &serv_canais){
	canais = serv_canais;
}

//---------------------------------------------------------------------

//retorna o id do dono do servidor
int Servidor::getDonoId(){
	return usuarioDonoId;
}
//retorna o nome do servidor
string Servidor::getNome(){
	return nome;
}
//retorna a descrição do servidor
string Servidor::getDescricao(){
	return descricao;
}
//retorna o código de convite do servidor
string Servidor::getCodigo(){
	return codigoConvite;
}
//retorna os canais do servidor
vector<Canal *> Servidor::getCanais(){
	return canais;
}
//retorna os ids dos participantes do servidor
vector<int> Servidor::getParticipantes(){
	return participantesIDs;
}

//---------------------------------------------------------------------

//faz uma cópia dos canais do servidor
vector<Canal *> Servidor::canaisCopy(){
	vector<Canal> cpy;
	vector<Canal *> c;
	vector<Canal>::iterator it;

	for(long unsigned int i = 0; i < canais.size(); i++){
		cpy.push_back((*canais.at(i)));
	}

	for(long unsigned int j = 0; j < cpy.size(); j++){
		c.push_back((&cpy.at(j)));
	}

	return c;
}

//---------------------------------------------------------------------

//cria um novo servidor
void Servidor::newServer(vector<string> &stream, int &id){
	usuarioDonoId = id;
	nome = stream[1];
}

//adiciona um usuário à lista de participantes do servidor
void Servidor::novoParticipante(Usuario &user){
	bool ja_esta = false;
	vector<int>::iterator it;

	for(it = participantesIDs.begin(); it != participantesIDs.end(); it++){
		if(*it == user.getId()){
			ja_esta = true;
		}
	}

	if(ja_esta == false){
		participantesIDs.push_back(user.getId());
	}
}

//cria um novo canal dentro do servidor
void Servidor::newChannel(vector<string> &stream){
	Canal *c;

	if(stream.size() == 3){ //verifica se o comando está completo
		//se o tipo for texto		
		if(stream[2] == "texto"){
			c = new CanalTexto;
			c->newChannel(stream);
			if(canais.empty() == true){
				canais.push_back(c);
				cout << "Canal \'" << c->getNome() << "\' criado com sucesso." << endl;
			}
			else{
				//verifica se um canal com este nome e este tipo já foi criado
				if(c->searchCanalBool(canais) == true){
					cout << "ERRO: Canal com este nome e deste tipo já foi criado." << endl;
				}
				else{
					canais.push_back(c);
					cout << "Canal \'" << c->getNome() << "\' criado com sucesso." << endl;
				}
			}
		}
		//se o tipo for voz
		else if(stream[2] == "voz"){
			c = new CanalVoz;
			c->newChannel(stream);
			if(canais.empty() == true){
				canais.push_back(c);
				cout << "Canal \'" << c->getNome() << "\' criado com sucesso." << endl;
			}
			else{
				//verifica se um canal com este nome e este tipo já foi criado
				if(c->searchCanalBool(canais) == true){
					cout << "ERRO: Canal com este nome e deste tipo já foi criado." << endl;
				}
				else{
					canais.push_back(c);
					cout << "Canal \'" << c->getNome() << "\' criado com sucesso." << endl;
				}	
			}
		}
		//se o tipo for inválido
		else{
			cout << "ERRO: Tipo de canal inválido." << endl;
		}
	}
	//se o comando estiver incompleto
	else{
		cout << "ERRO: É necessário especificar o tipo do canal." << endl;
	}
	c = nullptr;
}

//---------------------------------------------------------------------

//listando os canais do servidor
void Servidor::listChannels(){
	vector<Canal *>::iterator it;

	cout << "#canais de texto" << endl;
	for(it = canais.begin(); it != canais.end(); it++){
		if((*it)->getType() == 1){
			cout << (*it)->getNome() << endl;
		}
	}

	cout << "#canais de voz" << endl;
	for(it = canais.begin(); it != canais.end(); it++){
		if((*it)->getType() == 2){
			cout << (*it)->getNome() << endl;
		}
	}
}

//---------------------------------------------------------------------

//busca um canal pelo nome
Canal * Servidor::searchCanal(string &nome, string tipo){
	Canal *channel = new Canal;
	vector<Canal *>::iterator it;

	for(it = canais.begin(); it != canais.end(); it++){
		if(tipo == "\0"){
			if((*it)->getNome() == nome){
				channel = (*it);
				return channel;
			}
		}
		else if(tipo == "voz"){
			if((*it)->getNome() == nome){
				if((*it)->getType() == 2){
					channel = (*it);
					return channel;
				}
			}
		}
		else if(tipo == "texto"){
			if((*it)->getNome() == nome){
				if((*it)->getType() == 1){
					channel = (*it);
					return channel;
				}
			}
		}
		else{
			cout << "ERRO: Tipo inválido." << endl;
			return channel;
		}
	}
	return nullptr;
}

//---------------------------------------------------------------------

//anulando um servidor
Servidor Servidor::null(){
	usuarioDonoId = 0;
	nome = "\0";
	descricao = "\0";
	codigoConvite = "\0";
	//canais.clear();
	participantesIDs.clear();

	return *this;
}

//---------------------------------------------------------------------

//destrutor
Servidor::~Servidor(){
}