#ifndef _SERVIDOR_HPP_
#define _SERVIDOR_HPP_

#include <string>
#include <vector>
#include "canal.hpp"
#include "usuario.hpp"

using namespace std;

class Servidor{
		int usuarioDonoId;
		string nome, descricao, codigoConvite;
		vector<Canal *> canais;
		vector<int> participantesIDs;
	public:
		Servidor();
		//---------------------------------------------------------------------
		void setDescricao(string &desc);
		void setCodigo(string &codigo);
		void setCanais(vector<Canal *> &serv_canais);
		//---------------------------------------------------------------------
		int getDonoId();
		string getNome();
		string getDescricao();
		string getCodigo();
		vector<Canal *> getCanais();
		vector<int> getParticipantes();
		//---------------------------------------------------------------------
		vector<Canal *> canaisCopy();
		//---------------------------------------------------------------------
		void newServer(vector<string> &stream, int &id);
		void novoParticipante(Usuario &user);
		void newChannel(vector<string> &stream);
		//---------------------------------------------------------------------
		void listChannels();
		//---------------------------------------------------------------------
		Canal * searchCanal(string &nome, string tipo = "\0");
		//---------------------------------------------------------------------
		Servidor null();
		//---------------------------------------------------------------------
		~Servidor();
};

#endif